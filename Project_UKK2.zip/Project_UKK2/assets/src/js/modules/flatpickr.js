// Usage: https://flatpickr.js.org/
import flatpickr from "flatpickr";

window.flatpickr = flatpickr;