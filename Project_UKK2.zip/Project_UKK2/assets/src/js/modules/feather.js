// Usage: https://feathericons.com/
import feather from "feather-icons";

document.addEventListener("DOMContentLoaded", () => {
    feather.replace();
});

window.feather = feather;