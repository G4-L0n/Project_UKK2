<div class="container-fluid p-0">
	    <h1 class="h3 mb-3"><strong>Profil</strong> Diri</h1>
	<div class="row">
		<div class="col-xl-6 col-xxl-5 d-flex">
			<div class="row">
				<div class="col-12 col-lg-12 col-xxl-9 d-flex">
					<div class="card flex-fill">
						<table class="table table-hover my-0">
							<thead>
								<tr>
									<th>
                                        <div class="col-lg-2 col-xl-12"> 
                                        <img src="<?= base_url('assets/static/img/avatars/avatar-6.jpg')?>" class="img-thumbnail img-fluid rounded me-1" alt="Ilang"/>
                                        </div>
                                    </th>
                                    
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Nama : <input type="text" name="" id=""></td>
									
								</tr>
								<tr>
									<td>Email : <input type="email" name="" id=""></td>
                                </tr>
                                <tr>
									<td>Password : <input type="password" name="" id=""></td>
                                </tr>
                                <tr>
									<td>Date : <input type="date" name="" id=""></td>
                                </tr>
                                <tr>
									<td>Number : <input type="number" name="" id=""></td>
                                </tr>
                                <tr>
									<td>File : <input type="file" name="" id=""></td>
								</tr>
								<tr>
									<td>Color : <input type="color" name="" id=""></td>
								</tr>		
								<tr>
									<td><input type="submit" value="Submit"><input type="reset" value="Reset"></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
</div>